(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/fish.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'cf8b54Rx3hAl6CFuISpgreO', 'fish', __filename);
// Script/fish.ts

Object.defineProperty(exports, "__esModule", { value: true });
var game_1 = require("./game");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var fish = /** @class */ (function (_super) {
    __extends(fish, _super);
    function fish() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.speedX = null;
        _this.speedY = null;
        _this.moveX = null;
        return _this;
    }
    fish.prototype.onLoad = function () {
        this.moveX = 0;
    };
    /** 设置鱼 类型 数据 速度 坐标 */
    fish.prototype.addfish = function (speed, sx, sy) {
        var degrees = (Math.random() * 50 - 50 / 2 >> 0);
        if (sx > 0) {
            degrees += 180;
        }
        //角度转弧度
        var radians = cc.degreesToRadians(degrees);
        //算出x、y方向的偏移量
        var point = cc.pForAngle(radians);
        this.speedX = speed * point.x;
        this.speedY = speed * point.y;
        this.node.rotation = -degrees;
        this.node.x = sx;
        this.node.y = sy;
    };
    fish.prototype.onCollisionEnter = function () {
        this.create_coin();
        this.node.destroy();
    };
    fish.prototype.create_coin = function () {
        var coin = cc.instantiate(cc.find("Canvas").getComponent(game_1.default).coin_Prefab);
        cc.find("Canvas/bg").addChild(coin);
        coin.position = this.node.position;
        coin.runAction(cc.sequence(cc.scaleTo(0.3, 2, 2), cc.scaleTo(0.3, 1, 1), cc.moveTo(0.5, cc.p(-550, -250))));
        setTimeout(function () {
            coin.destroy();
        }, 1500);
    };
    /** 鱼的更新 */
    fish.prototype.update = function (dt) {
        this.node.x += this.speedX;
        this.node.y += this.speedY;
        this.moveX += this.speedX;
        if ((Math.abs(this.moveX) / 2) > cc.winSize.width) {
            this.node.destroy();
        }
    };
    fish = __decorate([
        ccclass
    ], fish);
    return fish;
}(cc.Component));
exports.default = fish;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=fish.js.map
        