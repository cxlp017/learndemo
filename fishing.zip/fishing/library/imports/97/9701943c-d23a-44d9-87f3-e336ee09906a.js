"use strict";
cc._RF.push(module, '97019Q80jpE2Yfz4zbuCZBq', 'SpriteFrameSet');
// SpriteFrameSet.js

'use strict';

var SpriteFrameSet = cc.Class({
    name: 'SpriteFrameSet',
    properties: {
        language: '',
        spriteFrame: cc.SpriteFrame
    }
});

module.exports = SpriteFrameSet;

cc._RF.pop();