"use strict";
cc._RF.push(module, 'e1b90/rohdEk4SdmmEZANaD', 'game');
// Script/game.ts

Object.defineProperty(exports, "__esModule", { value: true });
var bullet_1 = require("./bullet");
var fish_1 = require("./fish");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var game = /** @class */ (function (_super) {
    __extends(game, _super);
    function game() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /** 炮台节点 */
        _this.battery = null;
        /** 炮台图集 */
        _this.battery_Atlas = null;
        /** 子弹预制 */
        _this.bullet_Prefab = [];
        /** 鱼种类预制 */
        _this.fish_Prefab = [];
        /** 鱼网预制 */
        _this.flue_Prefab = [];
        /** 金币预制 */
        _this.coin_Prefab = null;
        /** 炮台索引 */
        _this.battery_index = 1;
        /** 本地坐标 */
        _this.local = null;
        /** 角度偏移量 */
        _this.Rotation = null;
        /** 鱼种类随机数 */
        _this._random = null;
        /** 创建鱼的间隔 */
        _this.makeCounter = null;
        return _this;
    }
    game.prototype.onLoad = function () {
        cc.director.setDisplayStats(false); //屏蔽fps
        //开启碰撞功能
        var manager = cc.director.getCollisionManager();
        manager.enabled = true;
        //显示碰撞区域
        // manager.enabledDebugDraw = true;
        // manager.enabledDrawBoundingBox = true;
        this.makeCounter = 60 + Math.random() * 60; //间隔多少帧生成一条鱼
        cc.find("Canvas/bg").on(cc.Node.EventType.TOUCH_END, this.getlocation, this);
        cc.find("Canvas/bg").on(cc.Node.EventType.TOUCH_MOVE, this.getlocation, this);
    };
    /** 更换炮台 */
    game.prototype.change_battery = function (event, data) {
        if (data == 1) {
            if (this.battery_index >= 1) {
                this.battery_index++;
                if (this.battery_index > 3) {
                    this.battery_index = 1;
                }
            }
        }
        else if (data == 0) {
            if (this.battery_index <= 3) {
                this.battery_index--;
                if (this.battery_index < 1) {
                    this.battery_index = 3;
                }
            }
        }
        this.battery.getComponent(cc.Sprite).spriteFrame = this.battery_Atlas.getSpriteFrame(this.battery_index + "-1");
    };
    /** 炮台角度偏移 */
    game.prototype.getlocation = function (event) {
        //鼠标点击坐标（本地坐标）
        this.local = cc.find("Canvas/bg").convertToNodeSpaceAR(event.getLocation());
        //炮台坐标（本地坐标）
        this.change_angle(this.battery.position, this.local);
        this.battery.rotation = this.Rotation;
        this.create_bullet();
    };
    /** 角度转换 */
    game.prototype.change_angle = function (p1, p2) {
        var o = p2.x - p1.x;
        var a = p2.y - p1.y;
        var angle = Math.atan(o / a) * 180 / Math.PI;
        if (a < 0) {
            angle = (o < 0) ? 180 + Math.abs(angle) : 180 - Math.abs(angle);
        }
        this.Rotation = angle;
    };
    /** 点击生成子弹 */
    game.prototype.create_bullet = function () {
        var speed = 10;
        //角度转弧度
        var radians = cc.degreesToRadians(this.Rotation);
        //算出x、y方向的偏移量
        var point = cc.pForAngle(radians);
        var zidan = cc.instantiate(this.bullet_Prefab[this.battery_index - 1]);
        cc.find("Canvas/bg").addChild(zidan);
        zidan.x = this.battery.x + 100 * point.y;
        zidan.y = this.battery.y + 100 * point.x;
        zidan.getComponent(bullet_1.default).addbullet(speed * point.y, speed * point.x, this.Rotation, this.battery_index);
    };
    /** 创建鱼 */
    game.prototype.create_fish = function () {
        this._random = Math.floor(Math.random() * 3 + 1);
        var speed = 3;
        var yu = cc.instantiate(this.fish_Prefab[this._random - 1]);
        cc.find("Canvas/bg/bg").addChild(yu);
        var sx = Math.random() > 0.5 ? -cc.winSize.width / 2 - yu.width : cc.winSize.width / 2 + yu.width;
        var sy = Math.random() * (cc.winSize.height >> 1) - 100 >> 0;
        yu.setPosition(sx, sy);
        yu.getComponent(fish_1.default).addfish(speed, sx, sy);
    };
    game.prototype.update = function () {
        if (--this.makeCounter <= 0) {
            this.makeCounter = 60 + Math.random() * 60;
            this.create_fish();
        }
    };
    __decorate([
        property({
            type: cc.Node,
            tooltip: "炮台节点"
        })
    ], game.prototype, "battery", void 0);
    __decorate([
        property({
            type: cc.SpriteAtlas,
            tooltip: "炮台节点"
        })
    ], game.prototype, "battery_Atlas", void 0);
    __decorate([
        property({
            type: [cc.Prefab],
            tooltip: "炮台节点"
        })
    ], game.prototype, "bullet_Prefab", void 0);
    __decorate([
        property({
            type: [cc.Prefab],
            tooltip: "鱼种类预制"
        })
    ], game.prototype, "fish_Prefab", void 0);
    __decorate([
        property({
            type: [cc.Prefab],
            tooltip: "鱼网预制"
        })
    ], game.prototype, "flue_Prefab", void 0);
    __decorate([
        property({
            type: cc.Prefab,
            tooltip: "金币预制"
        })
    ], game.prototype, "coin_Prefab", void 0);
    game = __decorate([
        ccclass
    ], game);
    return game;
}(cc.Component));
exports.default = game;

cc._RF.pop();