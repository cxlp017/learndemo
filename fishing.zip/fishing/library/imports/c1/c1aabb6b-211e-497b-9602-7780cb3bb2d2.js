"use strict";
cc._RF.push(module, 'c1aabtrIR5Je5YCd4DLO7LS', 'bullet');
// Script/bullet.ts

Object.defineProperty(exports, "__esModule", { value: true });
var game_1 = require("./game");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var bullet = /** @class */ (function (_super) {
    __extends(bullet, _super);
    function bullet() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.speedX = null;
        _this.speedY = null;
        _this.index = null;
        _this.moveX = null;
        return _this;
    }
    bullet.prototype.onLoad = function () {
        this.moveX = 0;
    };
    bullet.prototype.addbullet = function (sx, sy, degree, index) {
        this.node.rotation = degree;
        this.speedX = sx;
        this.speedY = sy;
        this.index = index;
    };
    bullet.prototype.onCollisionEnter = function () {
        this.create_flue();
        this.node.destroy();
    };
    bullet.prototype.create_flue = function () {
        var yuwang = cc.instantiate(cc.find("Canvas").getComponent(game_1.default).flue_Prefab[this.index - 1]);
        cc.find("Canvas/bg").addChild(yuwang);
        yuwang.position = this.node.position;
        yuwang.runAction(cc.sequence(cc.scaleTo(0.3, 2, 2), cc.scaleTo(0.3, 1, 1)));
        setTimeout(function () {
            yuwang.destroy();
        }, 600);
    };
    bullet.prototype.update = function (dt) {
        this.node.x += this.speedX;
        this.node.y += this.speedY;
        this.moveX += this.speedX;
        if ((Math.abs(this.moveX)) > (cc.winSize.width / 2)) {
            this.node.destroy();
        }
    };
    bullet = __decorate([
        ccclass
    ], bullet);
    return bullet;
}(cc.Component));
exports.default = bullet;

cc._RF.pop();