import bullet from "./bullet";
import fish from "./fish";

const {ccclass, property} = cc._decorator;

@ccclass
export default class game extends cc.Component {

    /** 炮台节点 */
    @property({
        type:cc.Node,
        tooltip: "炮台节点"
    })
    private battery:cc.Node = null;

    /** 炮台图集 */
    @property({
        type:cc.SpriteAtlas,
        tooltip: "炮台节点"
    })
    private battery_Atlas:cc.SpriteAtlas = null;

    /** 子弹预制 */
    @property({
        type:[cc.Prefab],
        tooltip: "炮台节点"
    })
    private bullet_Prefab:Array<cc.Prefab> = [];

    /** 鱼种类预制 */
    @property({
        type:[cc.Prefab],
        tooltip: "鱼种类预制"
    })
    private fish_Prefab:Array<cc.Prefab> = [];

    /** 鱼网预制 */
    @property({
        type:[cc.Prefab],
        tooltip: "鱼网预制"
    })
    public flue_Prefab:Array<cc.Prefab> = [];

    /** 金币预制 */
    @property({
        type:cc.Prefab,
        tooltip: "金币预制"
    })
    public coin_Prefab:cc.Prefab = null;

    /** 炮台索引 */
    private battery_index:number = 1;

    /** 本地坐标 */
    private local:cc.Vec2 = null;

    /** 角度偏移量 */
    private Rotation:number = null;

    /** 鱼种类随机数 */
    private _random:number = null

    /** 创建鱼的间隔 */
    private makeCounter:number = null;

    onLoad(){
        cc.director.setDisplayStats(false);     //屏蔽fps
        //开启碰撞功能
        var manager = cc.director.getCollisionManager();
        manager.enabled = true;
        //显示碰撞区域
        // manager.enabledDebugDraw = true;
        // manager.enabledDrawBoundingBox = true;
        this.makeCounter = 60+Math.random()*60;    //间隔多少帧生成一条鱼
        cc.find("Canvas/bg").on(cc.Node.EventType.TOUCH_END, this.getlocation, this);
        cc.find("Canvas/bg").on(cc.Node.EventType.TOUCH_MOVE, this.getlocation, this);
    }

    /** 更换炮台 */
    change_battery(event,data){
        if(data == 1){
            if(this.battery_index >= 1){
                this.battery_index++;
                if(this.battery_index > 3){
                    this.battery_index = 1;
                }
            }
        }else if(data == 0){
            if(this.battery_index <= 3){
                this.battery_index--;
                if(this.battery_index < 1){
                    this.battery_index = 3;
                }
            }
        }
        this.battery.getComponent(cc.Sprite).spriteFrame = this.battery_Atlas.getSpriteFrame(this.battery_index + "-1");
    }

    /** 炮台角度偏移 */
    getlocation(event){
        //鼠标点击坐标（本地坐标）
        this.local = cc.find("Canvas/bg").convertToNodeSpaceAR(event.getLocation());
        //炮台坐标（本地坐标）
        this.change_angle(this.battery.position,this.local);
        this.battery.rotation = this.Rotation;
        this.create_bullet();
    }

    /** 角度转换 */ 
    change_angle(p1, p2){
        var o = p2.x - p1.x;
        var a = p2.y - p1.y;
        var angle = Math.atan(o / a) * 180 / Math.PI;
        if (a < 0){
            angle = (o < 0)? 180 + Math.abs(angle):180 - Math.abs(angle);
        }
        this.Rotation = angle;
    }

    /** 点击生成子弹 */
    create_bullet(){
        var speed = 10;
        //角度转弧度
        var radians = cc.degreesToRadians(this.Rotation);
        //算出x、y方向的偏移量
        var point = cc.pForAngle(radians);
        let zidan = cc.instantiate(this.bullet_Prefab[this.battery_index - 1]);
        cc.find("Canvas/bg").addChild(zidan);
        zidan.x = this.battery.x + 100 * point.y;
        zidan.y = this.battery.y + 100 * point.x;
        zidan.getComponent(bullet).addbullet(speed * point.y, speed * point.x, this.Rotation,this.battery_index);
    }

    /** 创建鱼 */
    create_fish(){
        this._random = Math.floor(Math.random() * 3 + 1);
        var speed = 3;
        let yu = cc.instantiate(this.fish_Prefab[this._random-1]);
        cc.find("Canvas/bg/bg").addChild(yu);
        var sx = Math.random() > 0.5 ? -cc.winSize.width/2 - yu.width : cc.winSize.width/2 + yu.width;
        var sy = Math.random()* (cc.winSize.height >> 1) - 100 >> 0;
        yu.setPosition(sx,sy);
        yu.getComponent(fish).addfish(speed, sx, sy);
    }

    update(){
        if(--this.makeCounter <= 0){
            this.makeCounter = 60+Math.random()*60;
            this.create_fish();
        }
    }
}
