import game from "./game";

const {ccclass, property} = cc._decorator;

@ccclass
export default class fish extends cc.Component {

    private speedX:number = null;
    private speedY:number = null;
    private moveX:number = null;

    onLoad() {
        this.moveX = 0;
    }

    /** 设置鱼 类型 数据 速度 坐标 */
    addfish(speed, sx, sy){
        var degrees  = (Math.random() * 50 - 50/2 >> 0)
        if(sx > 0){
            degrees += 180;
        }
        //角度转弧度
        var radians = cc.degreesToRadians(degrees);
        //算出x、y方向的偏移量
        var point = cc.pForAngle(radians);
        this.speedX = speed * point.x;
        this.speedY = speed * point.y;
        this.node.rotation = -degrees;
        this.node.x = sx;
        this.node.y = sy;
    }

    onCollisionEnter(){
        this.create_coin();
        this.node.destroy();
    }

    create_coin(){
        let coin = cc.instantiate(cc.find("Canvas").getComponent(game).coin_Prefab);
        cc.find("Canvas/bg").addChild(coin);
        coin.position = this.node.position;
        coin.runAction(cc.sequence(cc.scaleTo(0.3,2,2),cc.scaleTo(0.3,1,1),cc.moveTo(0.5,cc.p(-550,-250))));
        setTimeout(() => {
            coin.destroy();
        }, 1500);
    }

    /** 鱼的更新 */
    update(dt) {
        this.node.x += this.speedX;
        this.node.y += this.speedY;
        this.moveX += this.speedX;
        if((Math.abs(this.moveX)/2) > cc.winSize.width){
            this.node.destroy();
        }
    }
}
