import game from "./game";

const {ccclass, property} = cc._decorator;

@ccclass
export default class bullet extends cc.Component {

    private speedX:number = null;
    private speedY:number = null;
    private index:number = null;
    private moveX:number = null;

    onLoad () {
        this.moveX = 0;
    }

    addbullet (sx,sy,degree,index) {
        this.node.rotation = degree;
        this.speedX = sx;
        this.speedY = sy;
        this.index = index;
    }

    onCollisionEnter(){
        this.create_flue();
        this.node.destroy();
    }

    create_flue(){
        let yuwang = cc.instantiate(cc.find("Canvas").getComponent(game).flue_Prefab[this.index-1]);
        cc.find("Canvas/bg").addChild(yuwang);
        yuwang.position = this.node.position;
        yuwang.runAction(cc.sequence(cc.scaleTo(0.3,2,2),cc.scaleTo(0.3,1,1)));
        setTimeout(() => {
            yuwang.destroy();
        }, 600);
    }

    update (dt) {
        this.node.x += this.speedX;
        this.node.y += this.speedY;
        this.moveX += this.speedX;
        if((Math.abs(this.moveX)) > (cc.winSize.width / 2)){
            this.node.destroy();
        }
    }
}
