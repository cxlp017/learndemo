"use strict";
cc._RF.push(module, '633acka1Y1KMKO0MlSu/x1+', 'ratation - 001');
// ratation - 001.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        speed: 100
    },

    onLoad: function onLoad() {
        this.v = new cc.Vec3(0, 0, 0);
    },
    update: function update(dt) {
        this.v.x += this.speed * dt;
        if (this.v.x > 359) {
            this.v.x = 0;
        }
        this.v.y += this.speed * dt;
        if (this.v.y > 359) {
            this.v.y = 0;
        }
        this.v.z += this.speed * dt;
        if (this.v.z > 359) {
            this.v.z = 0;
        }
        this.node.eulerAngles = this.v;
    }
});

cc._RF.pop();