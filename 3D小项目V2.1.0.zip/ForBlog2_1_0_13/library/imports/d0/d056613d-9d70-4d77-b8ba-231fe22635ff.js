"use strict";
cc._RF.push(module, 'd0566E9nXBNd7i6Ix/iJjX/', 'jump');
// jump.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {
        var act = cc.sequence(cc.moveBy(0.5, 0, -6.7).easing(cc.easeIn(2.5)), cc.moveBy(0.5, 0, 6.7).easing(cc.easeOut(2.5)));
        this.node.runAction(cc.repeatForever(act));
    },
    start: function start() {
        console.log(this.node);
    },
    update: function update(dt) {
        //this.node.y -= 2 * dt;
    }
});

cc._RF.pop();