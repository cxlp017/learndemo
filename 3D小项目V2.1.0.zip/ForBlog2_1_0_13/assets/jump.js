cc.Class({
    extends: cc.Component,

    properties: {
    },
    
    onLoad () {
        var act = cc.sequence(cc.moveBy(0.5,0,-6.7).easing(cc.easeIn(2.5)),cc.moveBy(0.5,0,6.7).easing(cc.easeOut(2.5)));
        this.node.runAction(cc.repeatForever(act));
    },

    start () {
        console.log(this.node);
    },

    update (dt) {
        //this.node.y -= 2 * dt;
    },
});
