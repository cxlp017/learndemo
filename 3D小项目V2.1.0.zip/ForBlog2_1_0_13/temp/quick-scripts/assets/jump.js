(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/jump.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'd0566E9nXBNd7i6Ix/iJjX/', 'jump', __filename);
// jump.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {
        var act = cc.sequence(cc.moveBy(0.5, 0, -6.7).easing(cc.easeIn(2.5)), cc.moveBy(0.5, 0, 6.7).easing(cc.easeOut(2.5)));
        this.node.runAction(cc.repeatForever(act));
    },
    start: function start() {
        console.log(this.node);
    },
    update: function update(dt) {
        //this.node.y -= 2 * dt;
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=jump.js.map
        