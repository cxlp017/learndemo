(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/ratation.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'e11dckXM0hED7oQs1NvgyaY', 'ratation', __filename);
// ratation.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        speed: 100
    },

    onLoad: function onLoad() {
        this.v = new cc.Vec3(0, 0, 0);
    },
    update: function update(dt) {
        this.v.x += this.speed * dt;
        if (this.v.x > 359) {
            this.v.x = 0;
        }
        //this.v.y += this.speed * dt;
        //if (this.v.y >359) {
        //    this.v.y = 0;
        //}
        //this.v.z += this.speed * dt;
        //if (this.v.z >359) {
        //    this.v.z = 0;
        //}
        this.node.eulerAngles = this.v;
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=ratation.js.map
        