"use strict";
cc._RF.push(module, '514abLiFI5KvoFlhe2FbOnv', 'zhujue');
// zhujue.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        speed: 0
    },

    onLoad: function onLoad() {
        this.speed = 100;
        this.v = new cc.Vec3(0, 0, 0);
    },
    start: function start() {},
    update: function update(dt) {
        this.v.x += this.speed * dt;
        this.v.y += this.speed * dt;
        this.v.z += this.speed * dt;
        this.node.eulerAngles = this.v;
    }
});

cc._RF.pop();