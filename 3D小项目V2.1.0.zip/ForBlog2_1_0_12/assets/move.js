cc.Class({
    extends: cc.Component,

    properties: {
        speed : 0,
    },

    onLoad () {
        this.speed = 100;
        // 标志位
        this.w_flag = 0;
        this.a_flag = 0;
        this.s_flag = 0;
        this.d_flag = 0;
        this.q_flag = 0;
        this.e_flag = 0;
        this.u_flag = 0;
    },

    start () {
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
    },

    onKeyDown (event) {
        switch(event.keyCode) {
            case cc.macro.KEY.w:
                this.w_flag = 1;
                break;
            case cc.macro.KEY.a:
                this.a_flag = 1;
                break;
            case cc.macro.KEY.s:
                this.s_flag = 1;
                break;
            case cc.macro.KEY.d:
                this.d_flag = 1;
                break;
            case cc.macro.KEY.q:
                this.q_flag = 1;
                break;
            case cc.macro.KEY.e:
                this.e_flag = 1;
                break;
            case cc.macro.KEY.u:
                this.u_flag = 1;
                break;
        }
    },

    onKeyUp (event) {
        switch(event.keyCode) {
            case cc.macro.KEY.w:
            this.w_flag = 0;
            break;
        case cc.macro.KEY.a:
            this.a_flag = 0;
            break;
        case cc.macro.KEY.s:
            this.s_flag = 0;
            break;
        case cc.macro.KEY.d:
            this.d_flag = 0;
            break;
        case cc.macro.KEY.q:
            this.q_flag = 0;
            break;
        case cc.macro.KEY.e:
            this.e_flag = 0;
            break;
        case cc.macro.KEY.u:
            this.u_flag = 0;
            break;
        }
    },

    update (dt) {
        if (this.w_flag) {
            this.node.z -= this.speed * dt;
        }
        if (this.a_flag) {
            this.node.x -= this.speed * dt;
        }
        if (this.s_flag) {
            this.node.z += this.speed * dt;
        }
        if (this.d_flag) {
            this.node.x += this.speed * dt;
        }
        if (this.u_flag) {
            this.node.y += this.speed * dt;
        }
        if (this.q_flag) {
            this.node.rotationY += this.speed * dt;
        }
        if (this.e_flag) {
            this.node.rotationY -= this.speed * dt;
        }
    },

    onDestroy () {
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
    },
});
