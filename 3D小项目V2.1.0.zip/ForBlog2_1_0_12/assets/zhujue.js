cc.Class({
    extends: cc.Component,

    properties: {
        speed : 0,
    },

    onLoad () {
        this.speed = 100;
        this.v = new cc.Vec3(0,0,0);
    },

    start () {

    },

    update (dt) {
        this.v.x += this.speed * dt;
        this.v.y += this.speed * dt;
        this.v.z += this.speed * dt;
        this.node.eulerAngles = this.v;
    },
});
