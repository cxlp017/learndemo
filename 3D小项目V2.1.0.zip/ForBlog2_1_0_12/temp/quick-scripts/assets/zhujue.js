(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/zhujue.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '514abLiFI5KvoFlhe2FbOnv', 'zhujue', __filename);
// zhujue.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        speed: 0
    },

    onLoad: function onLoad() {
        this.speed = 100;
        this.v = new cc.Vec3(0, 0, 0);
    },
    start: function start() {},
    update: function update(dt) {
        this.v.x += this.speed * dt;
        this.v.y += this.speed * dt;
        this.v.z += this.speed * dt;
        this.node.eulerAngles = this.v;
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=zhujue.js.map
        