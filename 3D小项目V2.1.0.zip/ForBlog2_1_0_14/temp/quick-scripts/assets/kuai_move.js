(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/kuai_move.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '4ab18GeZBFBY57oMB1iZl4b', 'kuai_move', __filename);
// kuai_move.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        zhujue: cc.Node,
        btu: cc.Node
    },

    update: function update(dt) {
        this.node.z += 200 * dt;
        if (this.node.z >= 0) {
            this.node.destroy();
        }
        // 碰撞检测
        var dis = this.node.position.sub(this.zhujue.position);
        // 计算距离
        if (dis.mag() <= 8) {
            // 游戏暂停
            cc.director.pause();
            this.btu.x = 0;
        }
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=kuai_move.js.map
        