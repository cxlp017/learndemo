"use strict";
cc._RF.push(module, '90b7dSWv7RI7JvLKAEeYPJ6', 'move');
// move.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        // 球球
        zhujue: cc.Node,
        music: {
            type: cc.AudioClip,
            default: null
        }
    },

    start: function start() {
        cc.audioEngine.playMusic(this.music, true);
        // 拖动函数
        this.node.on('touchmove', function (touch) {
            var delta = touch.getDelta();
            this.zhujue.x += delta.x;
        }, this);
    }
}

// update (dt) {},
);

cc._RF.pop();